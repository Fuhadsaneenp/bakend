import { Role } from "@prisma/client";
import { Router } from "express";
import { z } from "zod";
import { requireAuth, requireRoles } from "../../middleware/auth.js";
import { ApiError } from "../../lib/errors.js";
import { attendanceService } from "./attendance.service.js";
import { env } from "../../config/env.js";
import { prisma } from "../../lib/prisma.js";
import { runBiometricSync } from "../../routes/biometricSync.js";

export const attendanceRouter = Router();

const weekdayNames = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"] as const;

const shiftSchema = z.object({
  name: z.string().min(1),
  startTime: z.string().regex(/^([0-9]|0[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$/, "Invalid time format (HH:MM)"),
  endTime: z.string().regex(/^([0-9]|0[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$/, "Invalid time format (HH:MM)"),
  gracePeriod: z.number().int().nonnegative(),
  earlyPunchTolerance: z.number().int().nonnegative(),
  workMinutesFix: z.number().int().nonnegative(),
  workingDays: z.array(z.enum(weekdayNames)).min(1),
  effectiveFrom: z.string().optional(),
  scheduleType: z.enum(["Duration-based", "Clock-based"]).default("Clock-based"),
  isDefault: z.boolean().optional(),
  isActive: z.boolean().optional()
});

function parseWorkingDays(raw: string | null | undefined) {
  if (!raw) return ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"];
  try {
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed) && parsed.every((day) => typeof day === "string")) {
      return parsed;
    }
  } catch {}
  return ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"];
}

function serializeShift(shift: any) {
  return {
    ...shift,
    workingDays: parseWorkingDays(shift.workingDays)
  };
}

// Biometric webhook endpoint (requires x-biometric-key bypass header)
attendanceRouter.post("/biometric", async (req, res, next) => {
  try {
    const key = req.headers["x-biometric-key"];
    if (key !== env.BIOMETRIC_API_KEY) {
      throw new ApiError(401, "Unauthorized biometric key");
    }

    const bodySchema = z.object({
      biometricId: z.string(),
      punchTime: z.string(),
      direction: z.enum(["IN", "OUT"]).optional()
    });

    const isArray = Array.isArray(req.body);
    const punches = isArray
      ? z.array(bodySchema).parse(req.body)
      : [bodySchema.parse(req.body)];

    const results = [];
    for (const punch of punches) {
      const result = await attendanceService.biometricPunch(punch.biometricId, punch.punchTime, punch.direction);
      results.push(result);
    }
    res.status(200).json({ success: true, processed: results.length, data: results });
  } catch (error) {
    next(error);
  }
});

attendanceRouter.use(requireAuth);

attendanceRouter.post("/checkin", async (req, res, next) => {
  try {
    const body = z.object({ latitude: z.number().optional(), longitude: z.number().optional() }).parse(req.body);
    res.status(201).json(await attendanceService.checkIn(req.user!.id, body));
  } catch (error) {
    next(error);
  }
});

attendanceRouter.post("/checkout", async (req, res, next) => {
  try {
    res.json(await attendanceService.checkOut(req.user!.id));
  } catch (error) {
    next(error);
  }
});

attendanceRouter.get("/report", requireRoles(Role.SUPER_ADMIN, Role.HR_ADMIN, Role.MANAGER, Role.EMPLOYEE), async (req, res, next) => {
  try {
    const query = z.object({
      month: z.coerce.number().min(1).max(12),
      year: z.coerce.number().min(2020),
      companyId: z.string().optional()
    }).parse(req.query);
    res.json(await attendanceService.monthlyReportForUser(req.user!, query.month, query.year, query.companyId));
  } catch (error) {
    next(error);
  }
});

attendanceRouter.get("/biometric/logs", requireRoles(Role.SUPER_ADMIN, Role.HR_ADMIN, Role.MANAGER), async (req, res, next) => {
  try {
    const logs = await prisma.biometricRawLog.findMany({
      orderBy: { receivedAt: "desc" },
      take: 50
    });
    res.json(logs);
  } catch (error) {
    next(error);
  }
});

attendanceRouter.post("/biometric/sync", requireRoles(Role.SUPER_ADMIN, Role.HR_ADMIN, Role.MANAGER), async (req, res, next) => {
  try {
    await runBiometricSync();
    const { queueDeviceAttendanceUpload } = await import("../../lib/biometricDeviceSync.js");
    await queueDeviceAttendanceUpload("NFZ8254702089");
    res.json({ success: true, message: "Sync executed and device log query queued successfully" });
  } catch (error) {
    next(error);
  }
});

const cleanupSeededSchema = z.object({
  employeeCode: z.string().min(1),
  month: z.coerce.number().min(1).max(12),
  year: z.coerce.number().min(2020),
  dryRun: z.coerce.boolean().optional().default(false)
});

const repairFromRawSchema = z.object({
  employeeCode: z.string().min(1),
  month: z.coerce.number().min(1).max(12),
  year: z.coerce.number().min(2020),
  dryRun: z.coerce.boolean().optional().default(false)
});

const rebuildMonthFromMachineSchema = z.object({
  month: z.coerce.number().min(1).max(12),
  year: z.coerce.number().min(2020),
  dryRun: z.coerce.boolean().optional().default(false),
  employeeCode: z.string().min(1).optional(),
  companyId: z.string().min(1).optional()
});

function parseKolkataPunchTime(value: string) {
  if (!/\d{4}-\d{2}-\d{2}/.test(value)) return null;
  if (value.includes("Z") || value.includes("+")) return new Date(value);
  return new Date(value.replace(" ", "T") + "+05:30");
}

function isSeededFixedPunch(punchTime: Date) {
  const hours = punchTime.getUTCHours();
  const minutes = punchTime.getUTCMinutes();
  const seconds = punchTime.getUTCSeconds();
  return seconds === 0 && ((hours === 3 && minutes === 30) || (hours === 12 && minutes === 30));
}

function parseBiometricQueryParameters(raw: string | null | undefined) {
  try {
    const parsed = JSON.parse(raw || "{}");
    return typeof parsed === "object" && parsed ? parsed as Record<string, unknown> : {};
  } catch {
    return {};
  }
}

function isAttlogRawLog(log: { queryParameters?: string | null; rawPayload?: string | null }) {
  const query = parseBiometricQueryParameters(log.queryParameters);
  const tableValue = query.table ?? query.TABLE ?? query.Table ?? "";
  const table = String(tableValue || "").trim().toUpperCase();
  if (table) return table === "ATTLOG";
  return false;
}

function isPinMatch(pin1: string, pin2: string): boolean {
  const p1 = pin1.trim().toLowerCase();
  const p2 = pin2.trim().toLowerCase();
  if (p1 === p2) return true;

  const num1 = p1.replace(/\D/g, "");
  const num2 = p2.replace(/\D/g, "");
  if (!num1 || !num2) return false;

  if (Number(num1) === Number(num2)) {
    const verifySuffix = (str: string, num: string) => {
      if (/^\d+$/.test(str)) return true;
      return str.endsWith(num.padStart(3, "0"));
    };
    return verifySuffix(p1, num1) && verifySuffix(p2, num2);
  }
  return false;
}

function extractEmployeePunchesFromAttlog(rawPayload: string, allowedKeys: Set<string>, monthStart: Date, monthEnd: Date) {
  // Attendance rebuilds are intentionally locked to machine ATTLOG uploads only.
  // Do not infer punches from USERINFO, generated schedules, or synthetic defaults.
  const punches: string[] = [];
  const lines = String(rawPayload || "").split(/\r?\n/);

  for (const line of lines) {
    const trimmed = line.trim().replace(/^(ATTLOG|OPLOG|USERINFO|USER)\s+/i, "");
    if (!trimmed) continue;

    const match = trimmed.match(/^([^\t\s]+)[\t\s]+(\d{4}-\d{2}-\d{2}[\sT]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|\+\d{2}:?\d{2})?)/);
    const parts = match ? [match[1].trim(), match[2].trim()] : trimmed.split("\t").slice(0, 2).map((part) => part.trim());
    if (parts.length < 2) continue;

    const matchesAllowed = Array.from(allowedKeys).some((key) => isPinMatch(parts[0], key));
    if (!matchesAllowed) continue;

    const punchTime = parseKolkataPunchTime(parts[1]);
    if (!punchTime || Number.isNaN(punchTime.getTime())) continue;
    if (punchTime < monthStart || punchTime > monthEnd) continue;
    if (isSeededFixedPunch(punchTime)) continue;

    punches.push(parts[1]);
  }

  return Array.from(new Set(punches)).sort((a, b) => parseKolkataPunchTime(a)!.getTime() - parseKolkataPunchTime(b)!.getTime());
}

async function handleRepairAttendanceFromRaw(req: any, res: any, next: any) {
  try {
    const companyId = req.user?.companyId;
    if (!companyId) throw new ApiError(400, "Company context required");

    const rawInput = req.method === "GET" ? req.query : req.body;
    const body = repairFromRawSchema.parse(rawInput);

    const employee = await prisma.employee.findFirst({
      where: {
        companyId,
        employeeCode: body.employeeCode
      },
      include: { shift: true, user: true }
    });
    if (!employee) throw new ApiError(404, "Employee not found");

    const biometricKey = employee.biometricId || employee.employeeCode;
    const monthStart = new Date(`${body.year}-${String(body.month).padStart(2, "0")}-01T00:00:00+05:30`);
    const monthEnd = new Date(`${body.year}-${String(body.month).padStart(2, "0")}-${String(new Date(body.year, body.month, 0).getDate()).padStart(2, "0")}T23:59:59+05:30`);

    const attendanceRows = await prisma.attendance.findMany({
      where: {
        employeeId: employee.id,
        workDate: {
          gte: monthStart,
          lte: monthEnd
        }
      },
      select: {
        id: true,
        workDate: true,
        checkInAt: true,
        checkOutAt: true,
        workMinutes: true
      }
    });

    const seededAttendanceRows = attendanceRows.filter((row) => {
      if (!row.checkInAt || !row.checkOutAt) return false;
      return (
        row.checkInAt.getUTCHours() === 3 &&
        row.checkInAt.getUTCMinutes() === 30 &&
        row.checkOutAt.getUTCHours() === 12 &&
        row.checkOutAt.getUTCMinutes() === 30 &&
        Number(row.workMinutes || 0) === 540
      );
    });

    const logScanStart = new Date(monthStart.getTime() - 45 * 24 * 60 * 60 * 1000);
    const logScanEnd = new Date(monthEnd.getTime() + 7 * 24 * 60 * 60 * 1000);
    const rawLogs = await prisma.biometricRawLog.findMany({
      where: {
        requestMethod: "POST",
        receivedAt: {
          gte: logScanStart,
          lte: logScanEnd
        }
      },
      orderBy: { receivedAt: "asc" },
      select: {
        id: true,
        queryParameters: true,
        rawPayload: true
      }
    });

    const uniquePunches = rawLogs
      .filter(isAttlogRawLog)
      .flatMap((log) => extractEmployeePunchesFromAttlog(
        log.rawPayload || "",
        new Set([biometricKey, employee.employeeCode]),
        monthStart,
        monthEnd
      ));
    const orderedUniquePunches = Array.from(new Set(uniquePunches)).sort((a, b) => parseKolkataPunchTime(a)!.getTime() - parseKolkataPunchTime(b)!.getTime());
    const replayErrors: string[] = [];
    let restoredPunches = 0;

    if (!body.dryRun) {
      if (attendanceRows.length > 0) {
        await prisma.attendance.deleteMany({
          where: { id: { in: attendanceRows.map((row) => row.id) } }
        });
      }

      for (const punchTime of orderedUniquePunches) {
        try {
          await attendanceService.biometricPunch(biometricKey, punchTime);
          restoredPunches += 1;
        } catch (error: any) {
          replayErrors.push(`${punchTime}: ${error?.message || "Failed to replay punch"}`);
        }
      }
    }

    res.json({
      success: true,
      employeeCode: employee.employeeCode,
      removedSeededRows: body.dryRun ? 0 : attendanceRows.length,
      matchedSeededRows: seededAttendanceRows.length,
      restoredPunches: body.dryRun ? 0 : restoredPunches,
      matchedPunches: orderedUniquePunches.length,
      replayErrors,
      dryRun: body.dryRun
    });
  } catch (error) {
    next(error);
  }
}

async function handleRebuildMonthFromMachine(req: any, res: any, next: any) {
  try {
    const rawInput = req.method === "GET" ? req.query : req.body;
    const body = rebuildMonthFromMachineSchema.parse(rawInput);
    const requestedCompanyId =
      (req.user?.role === Role.SUPER_ADMIN || req.user?.role === Role.HR_ADMIN) && body.companyId
        ? body.companyId
        : undefined;
    const companyId = requestedCompanyId || req.user?.companyId;
    if (!companyId) throw new ApiError(400, "Company context required");

    const monthStart = new Date(`${body.year}-${String(body.month).padStart(2, "0")}-01T00:00:00+05:30`);
    const monthEnd = new Date(`${body.year}-${String(body.month).padStart(2, "0")}-${String(new Date(body.year, body.month, 0).getDate()).padStart(2, "0")}T23:59:59+05:30`);
    const logScanStart = new Date(monthStart.getTime() - 45 * 24 * 60 * 60 * 1000);
    const logScanEnd = new Date(monthEnd.getTime() + 7 * 24 * 60 * 60 * 1000);

    const employees = await prisma.employee.findMany({
      where: {
        companyId,
        ...(body.employeeCode ? { employeeCode: body.employeeCode } : {})
      },
      select: {
        id: true,
        employeeCode: true,
        biometricId: true
      }
    });
    if (employees.length === 0) throw new ApiError(404, "No employees found for rebuild");

    const rawLogs = await prisma.biometricRawLog.findMany({
      where: {
        requestMethod: "POST",
        receivedAt: {
          gte: logScanStart,
          lte: logScanEnd
        }
      },
      orderBy: { receivedAt: "asc" },
      select: {
        queryParameters: true,
        rawPayload: true
      }
    });

    const attlogPayloads = rawLogs.filter(isAttlogRawLog);
    const attendanceRows = await prisma.attendance.findMany({
      where: {
        employeeId: { in: employees.map((employee) => employee.id) },
        workDate: {
          gte: monthStart,
          lte: monthEnd
        }
      },
      select: { id: true }
    });

    const results: Array<{ employeeCode: string; matchedPunches: number; restoredPunches: number; replayErrors: number }> = [];

    if (!body.dryRun && attendanceRows.length > 0) {
      await prisma.attendance.deleteMany({
        where: { id: { in: attendanceRows.map((row) => row.id) } }
      });
    }

    for (const employee of employees) {
      const allowedKeys = new Set([employee.employeeCode, employee.biometricId || employee.employeeCode]);
      const employeePunches = attlogPayloads
        .flatMap((log) => extractEmployeePunchesFromAttlog(log.rawPayload || "", allowedKeys, monthStart, monthEnd));
      const orderedUniquePunches = Array.from(new Set(employeePunches)).sort((a, b) => parseKolkataPunchTime(a)!.getTime() - parseKolkataPunchTime(b)!.getTime());

      let restoredPunches = 0;
      const replayErrors: string[] = [];

      if (!body.dryRun) {
        const biometricKey = employee.biometricId || employee.employeeCode;
        for (const punchTime of orderedUniquePunches) {
          try {
            await attendanceService.biometricPunch(biometricKey, punchTime);
            restoredPunches += 1;
          } catch (error: any) {
            replayErrors.push(error?.message || "Failed to replay punch");
          }
        }
      }

      results.push({
        employeeCode: employee.employeeCode,
        matchedPunches: orderedUniquePunches.length,
        restoredPunches: body.dryRun ? 0 : restoredPunches,
        replayErrors: replayErrors.length
      });
    }

    res.json({
      success: true,
      month: body.month,
      year: body.year,
      dryRun: body.dryRun,
      employees: results.length,
      removedAttendanceRows: body.dryRun ? 0 : attendanceRows.length,
      attlogPayloads: attlogPayloads.length,
      results
    });
  } catch (error) {
    next(error);
  }
}

async function handleCleanupSeeded(req: any, res: any, next: any) {
  try {
    const companyId = req.user?.companyId;
    if (!companyId) throw new ApiError(400, "Company context required");

    const rawInput = req.method === "GET" ? req.query : req.body;
    const body = cleanupSeededSchema.parse(rawInput);

    const employee = await prisma.employee.findFirst({
      where: {
        companyId,
        employeeCode: body.employeeCode
      },
      select: { id: true, employeeCode: true, firstName: true, lastName: true }
    });
    if (!employee) throw new ApiError(404, "Employee not found");

    const monthStart = new Date(`${body.year}-${String(body.month).padStart(2, "0")}-01T00:00:00+05:30`);
    const monthEnd = new Date(`${body.year}-${String(body.month).padStart(2, "0")}-${String(new Date(body.year, body.month, 0).getDate()).padStart(2, "0")}T23:59:59+05:30`);

    const attendanceRows = await prisma.attendance.findMany({
      where: {
        employeeId: employee.id,
        workDate: {
          gte: monthStart,
          lte: monthEnd
        }
      },
      select: {
        id: true,
        workDate: true,
        checkInAt: true,
        checkOutAt: true,
        workMinutes: true
      }
    });

    const seededRows = attendanceRows.filter((row) => {
      if (!row.checkInAt || !row.checkOutAt) return false;
      return (
        row.checkInAt.getUTCHours() === 3 &&
        row.checkInAt.getUTCMinutes() === 30 &&
        row.checkOutAt.getUTCHours() === 12 &&
        row.checkOutAt.getUTCMinutes() === 30 &&
        Number(row.workMinutes || 0) === 540
      );
    });

    if (!body.dryRun && seededRows.length > 0) {
      await prisma.attendance.deleteMany({
        where: {
          id: { in: seededRows.map((row) => row.id) }
        }
      });
    }

    res.json({
      success: true,
      employeeCode: employee.employeeCode,
      removed: body.dryRun ? 0 : seededRows.length,
      matched: seededRows.length,
      dryRun: body.dryRun,
      sampleDates: seededRows.slice(0, 10).map((row) => row.workDate)
    });
  } catch (error) {
    next(error);
  }
}

attendanceRouter.get("/admin/cleanup-seeded", requireRoles(Role.SUPER_ADMIN, Role.HR_ADMIN, Role.MANAGER), handleCleanupSeeded);
attendanceRouter.post("/admin/cleanup-seeded", requireRoles(Role.SUPER_ADMIN, Role.HR_ADMIN, Role.MANAGER), handleCleanupSeeded);
attendanceRouter.get("/admin/repair-from-raw", requireRoles(Role.SUPER_ADMIN, Role.HR_ADMIN, Role.MANAGER), handleRepairAttendanceFromRaw);
attendanceRouter.post("/admin/repair-from-raw", requireRoles(Role.SUPER_ADMIN, Role.HR_ADMIN, Role.MANAGER), handleRepairAttendanceFromRaw);
attendanceRouter.get("/admin/rebuild-month-from-machine", requireRoles(Role.SUPER_ADMIN, Role.HR_ADMIN, Role.MANAGER), handleRebuildMonthFromMachine);
attendanceRouter.post("/admin/rebuild-month-from-machine", requireRoles(Role.SUPER_ADMIN, Role.HR_ADMIN, Role.MANAGER), handleRebuildMonthFromMachine);

// Shifts CRUD endpoints
attendanceRouter.get("/shifts", requireRoles(Role.SUPER_ADMIN, Role.HR_ADMIN, Role.EMPLOYEE), async (req, res, next) => {
  try {
    if (!req.user?.companyId) throw new ApiError(400, "Company context required");
    const shifts = await prisma.shift.findMany({
      where: { companyId: req.user.companyId },
      orderBy: { createdAt: "desc" }
    });
    res.json(shifts.map(serializeShift));
  } catch (error) {
    next(error);
  }
});

attendanceRouter.post("/shifts", requireRoles(Role.SUPER_ADMIN, Role.HR_ADMIN), async (req, res, next) => {
  try {
    const companyId = req.user?.companyId;
    if (!companyId) throw new ApiError(400, "Company context required");
    const body = shiftSchema.parse(req.body);

    const shift = await prisma.$transaction(async (tx) => {
      if (body.isDefault) {
        await tx.shift.updateMany({
          where: { companyId },
          data: { isDefault: false }
        });
      }

      return tx.shift.create({
        data: {
          companyId,
          name: body.name,
          startTime: body.startTime,
          endTime: body.endTime,
          gracePeriod: body.gracePeriod,
          earlyPunchTolerance: body.earlyPunchTolerance,
          workMinutesFix: body.workMinutesFix,
          workingDays: JSON.stringify(body.workingDays),
          effectiveFrom: body.effectiveFrom ? new Date(body.effectiveFrom) : new Date(),
          scheduleType: body.scheduleType,
          isDefault: body.isDefault ?? false,
          isActive: body.isActive ?? true
        }
      });
    });
    res.status(201).json(serializeShift(shift));
  } catch (error) {
    next(error);
  }
});

attendanceRouter.put("/shifts/:id", requireRoles(Role.SUPER_ADMIN, Role.HR_ADMIN), async (req, res, next) => {
  try {
    const companyId = req.user?.companyId;
    if (!companyId) throw new ApiError(400, "Company context required");
    const body = shiftSchema.parse(req.body);

    const existing = await prisma.shift.findFirst({
      where: { id: req.params.id, companyId }
    });
    if (!existing) throw new ApiError(404, "Shift not found");

    const shift = await prisma.$transaction(async (tx) => {
      if (body.isDefault) {
        await tx.shift.updateMany({
          where: { companyId, id: { not: req.params.id } },
          data: { isDefault: false }
        });
      }

      return tx.shift.update({
        where: { id: req.params.id },
        data: {
          name: body.name,
          startTime: body.startTime,
          endTime: body.endTime,
          gracePeriod: body.gracePeriod,
          earlyPunchTolerance: body.earlyPunchTolerance,
          workMinutesFix: body.workMinutesFix,
          workingDays: JSON.stringify(body.workingDays),
          effectiveFrom: body.effectiveFrom ? new Date(body.effectiveFrom) : existing.effectiveFrom,
          scheduleType: body.scheduleType,
          isDefault: body.isDefault ?? existing.isDefault,
          isActive: body.isActive ?? existing.isActive
        }
      });
    });
    res.json(serializeShift(shift));
  } catch (error) {
    next(error);
  }
});

attendanceRouter.delete("/shifts/:id", requireRoles(Role.SUPER_ADMIN, Role.HR_ADMIN), async (req, res, next) => {
  try {
    if (!req.user?.companyId) throw new ApiError(400, "Company context required");
    const existing = await prisma.shift.findFirst({
      where: { id: req.params.id, companyId: req.user.companyId }
    });
    if (!existing) throw new ApiError(404, "Shift not found");

    const employeesCount = await prisma.employee.count({
      where: { shiftId: req.params.id }
    });
    if (employeesCount > 0) {
      throw new ApiError(400, "Cannot delete shift because it is assigned to employees");
    }
    if (existing.isDefault) {
      throw new ApiError(400, "Cannot delete the default work schedule. Set another schedule as default first.");
    }

    await prisma.shift.delete({
      where: { id: req.params.id }
    });
    res.json({ success: true });
  } catch (error) {
    next(error);
  }
});
