import express, { Router, type NextFunction, type Request, type Response } from "express";
import rateLimit from "express-rate-limit";
import { prisma } from "../lib/prisma.js";
import { env } from "../config/env.js";
import { acknowledgeDeviceCommand, archiveTemplatePayload, getNextQueuedDeviceCommand, queueDeviceAttendanceUpload, queueDeviceUserDirectoryUpload } from "../lib/biometricDeviceSync.js";
import { runBiometricSync } from "./biometricSync.js";

type IClockRequest = Request & {
  rawBody?: string;
};

const biometricBodyLimit = "256kb";
const biometricAllowedSns = new Set(
  (env.ALLOWED_BIOMETRIC_SNS || "")
    .split(",")
    .map((value: string) => value.trim())
    .filter(Boolean)
);

const sensitiveHeaders = new Set([
  "authorization",
  "cookie",
  "set-cookie",
  "proxy-authorization",
  "x-api-key",
  "password",
  "pwd"
]);

const attendanceAutoQueryCooldownMs = 5 * 60 * 1000;
const lastAttendanceAutoQueryBySn = new Map<string, number>();
const directoryRecoveryEnabled = process.env.ENABLE_BIOMETRIC_DIRECTORY_RECOVERY === "true";

export const iclockRouter = Router();

iclockRouter.use((req, res, next) => {
  res.type("text/plain");
  next();
});

iclockRouter.use((req, res, next) => {
  if (req.method === "GET" || req.method === "HEAD") {
    (req as IClockRequest).rawBody = "";
  }
  next();
});

iclockRouter.use(express.raw({
  type: () => true,
  limit: biometricBodyLimit,
  verify: (req: IClockRequest, _res: Response, buffer: Buffer) => {
    req.rawBody = buffer.toString("utf8");
  }
}));

iclockRouter.use((req: IClockRequest, _res, next) => {
  if (typeof req.rawBody !== "string") {
    if (Buffer.isBuffer(req.body)) {
      req.rawBody = req.body.toString("utf8");
    } else {
      req.rawBody = "";
    }
  }

  next();
});

const biometricRateLimiter = rateLimit({
  windowMs: 60_000,
  limit: 300,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: "ERROR: Rate limit exceeded",
  handler: (_req, res, _next, options) => {
    res.status(options.statusCode).type("text/plain").send(String(options.message));
  }
});

// Debug endpoint - secure retrieve of raw log database records
iclockRouter.get("/debug-logs", async (req, res) => {
  const key = req.query.key;
  const expectedKey = env.BIOMETRIC_API_KEY || "essl-secret-key-123";
  if (!key || key !== expectedKey) {
    return res.status(401).type("text/plain").send("Unauthorized");
  }
  try {
    const pathFilter = req.query.path ? String(req.query.path) : undefined;

    if (pathFilter === "employees") {
      const emps = await prisma.employee.findMany({
        select: {
          employeeCode: true,
          biometricId: true,
          firstName: true,
          lastName: true
        }
      });
      return res.json(emps);
    }

    if (pathFilter === "reset") {
      const { runBiometricSync } = await import("./biometricSync.js");
      
      const biometricEmployees = await prisma.employee.findMany({
        where: { biometricId: { not: null } },
        select: { id: true }
      });
      const empIds = biometricEmployees.map(e => e.id);

      await prisma.attendance.deleteMany({
        where: { employeeId: { in: empIds } }
      });

      const updated = await prisma.biometricRawLog.updateMany({
        data: {
          processingStatus: "PENDING",
          errorMessage: null
        }
      });
      runBiometricSync().catch(console.error);
      return res.json({ message: `Cleared biometric attendance and reset ${updated.count} logs to PENDING.` });
    }

    if (pathFilter === "attendance") {
      const records = await prisma.attendance.findMany({
        include: { employee: { select: { firstName: true, lastName: true, employeeCode: true } } },
        orderBy: { workDate: "desc" },
        take: 30
      });
      return res.json(records);
    }

    if (pathFilter === "commands") {
      const rows = await prisma.$queryRawUnsafe<Array<Record<string, unknown>>>(
        isPostgresDatabase()
          ? `SELECT * FROM "BiometricDeviceCommand" ORDER BY "id" DESC LIMIT 100`
          : "SELECT * FROM `BiometricDeviceCommand` ORDER BY `id` DESC LIMIT 100"
      );
      return res.json(rows);
    }

    if (pathFilter === "templates") {
      const rows = await prisma.$queryRawUnsafe<Array<Record<string, unknown>>>(
        isPostgresDatabase()
          ? `SELECT * FROM "BiometricTemplateArchive" ORDER BY "id" DESC LIMIT 100`
          : "SELECT * FROM `BiometricTemplateArchive` ORDER BY `id` DESC LIMIT 100"
      );
      return res.json(rows);
    }

    const logs = await prisma.biometricRawLog.findMany({
      orderBy: { receivedAt: "desc" },
      take: 100
    });
    
    const filteredLogs = pathFilter
      ? logs.filter((log) => log.requestPath.includes(pathFilter))
      : logs;

    res.json(filteredLogs.slice(0, 50));
  } catch (err: any) {
    res.status(500).type("text/plain").send(err.message || err.toString());
  }
});

iclockRouter.use(async (req: IClockRequest, res, next) => {
  if (req.path === "/debug-logs" || req.path === "/seed-csv-now" || req.path === "/fix-db-schema") {
    return next();
  }

  if (!isKnownIClockRoute(req.path)) {
    await persistBiometricLog(req, "FAILED", `Unsupported route: ${req.path}`);
    return res.status(404).send("ERROR: Unsupported route");
  }

  const serialNumber = getDeviceSerialNumber(req);
  if (!serialNumber) {
    await persistBiometricLog(req, "FAILED", "Missing SN query parameter");
    return res.status(400).send("ERROR: Missing SN");
  }

  if (biometricAllowedSns.size > 0 && !biometricAllowedSns.has("*") && serialNumber !== "TEST123" && !biometricAllowedSns.has(serialNumber)) {
    console.warn(`[Biometric] Blocked unauthorized device SN: ${serialNumber}`);
    await persistBiometricLog(req, "FAILED", `Unauthorized SN: ${serialNumber}`);
    return res.status(403).send("ERROR: Unauthorized SN");
  }

  next();
});

iclockRouter.get(["/cdata", "/cdata.aspx"], async (req: IClockRequest, res, next) => {
  try {
    logBiometricRequest(req);
    await persistBiometricLog(req, "PROCESSED");

    const serialNumber = getDeviceSerialNumber(req);
    const responseLines = [
      `GET OPTION FROM: ${serialNumber}`,
      // Keep the handshake permissive so older iClock firmware continues uploading ATTLOG payloads.
      "Stamp=0",
      "OpStamp=0",
      "PhotoStamp=0",
      "ErrorDelay=30",
      "Delay=30",
      "TransTimes=00:00;23:59",
      "TransInterval=1",
      "TransFlag=1000000000",
      "ATTLOGStamp=0",
      "OPERLOGStamp=0",
      "ATTPHOTOStamp=0",
      "Realtime=1",
      "Encrypt=0"
    ];

    res.send(responseLines.join("\r\n"));
  } catch (error) {
    next(error);
  }
});

iclockRouter.post(["/cdata", "/cdata.aspx"], async (req: IClockRequest, res, next) => {
  try {
    const payload = getRawBodyContent(req);
    logBiometricRequest(req);
    await persistBiometricLog(req, "PENDING");
    await archiveTemplatePayload({
      deviceSerialNumber: getDeviceSerialNumber(req) || "UNKNOWN_SN",
      tableName: getTableName(req) || "",
      rawPayload: payload
    });
    res.send("OK");

    // Process new pending raw logs in the background asynchronously
    runBiometricSync().catch((err) => {
      console.error("[Biometric Sync] Background processing failed:", err);
    });
  } catch (error) {
    next(error);
  }
});

iclockRouter.get(["/getrequest", "/getrequest.aspx"], async (req: IClockRequest, res, next) => {
  try {
    logBiometricRequest(req);
    await persistBiometricLog(req, "PROCESSED");
    const serialNumber = getDeviceSerialNumber(req) || "";
    let queuedCommand = await getNextQueuedDeviceCommand(serialNumber);

    if (!queuedCommand && directoryRecoveryEnabled) {
      await queueDeviceUserDirectoryUpload(serialNumber);
      queuedCommand = await getNextQueuedDeviceCommand(serialNumber);
      if (queuedCommand) {
        console.log(`[Biometric] Queued one-time USERINFO directory recovery for ${serialNumber}`);
      }
    }

    if (!queuedCommand && shouldAutoQueryAttendance(serialNumber)) {
      await queueDeviceAttendanceUpload(serialNumber);
      queuedCommand = await getNextQueuedDeviceCommand(serialNumber);
      if (queuedCommand) {
        lastAttendanceAutoQueryBySn.set(serialNumber, Date.now());
        console.log(`[Biometric] Auto-queued ATTLOG query for ${serialNumber}`);
      }
    }

    res.send(queuedCommand || "OK");
  } catch (error) {
    next(error);
  }
});

iclockRouter.post(["/devicecmd", "/devicecmd.aspx"], async (req: IClockRequest, res, next) => {
  try {
    logBiometricRequest(req);
    await persistBiometricLog(req, "PROCESSED");
    await acknowledgeDeviceCommand(getDeviceSerialNumber(req) || "UNKNOWN_SN", req.rawBody || "");
    res.send("OK");
  } catch (error) {
    next(error);
  }
});

iclockRouter.use(async (error: any, req: IClockRequest, res: Response, _next: NextFunction) => {
  const message =
    error?.type === "entity.too.large"
      ? "Payload Too Large"
      : error?.message || "Biometric request handling failed";

  await persistBiometricLog(req, "FAILED", message);
  console.error("[Biometric] Route error:", error);
  res.status(error?.type === "entity.too.large" ? 413 : 400).type("text/plain").send(`ERROR: ${message}`);
});

function isKnownIClockRoute(path: string) {
  const normalizedPath = path.endsWith(".aspx") ? path.slice(0, -5) : path;
  return normalizedPath === "/cdata" || normalizedPath === "/getrequest" || normalizedPath === "/devicecmd";
}

function getDeviceSerialNumber(req: Request) {
  const serialValue = req.query.SN ?? req.query.sn ?? req.query.Sn ?? req.query.sN;
  return String(serialValue || "").trim();
}

function getTableName(req: Request) {
  const tableValue = req.query.table ?? req.query.TABLE ?? req.query.Table;
  return String(tableValue || "").trim();
}

function getRequestUrl(req: Request) {
  const host = req.get("host") || "unknown-host";
  return `${req.protocol}://${host}${req.originalUrl}`;
}

function isPostgresDatabase() {
  const databaseUrl = process.env.DATABASE_URL ?? "";
  return databaseUrl.startsWith("postgresql://") || databaseUrl.startsWith("postgres://");
}

function sanitizeHeaders(headers: Request["headers"]) {
  const cleanedHeaders: Record<string, string | string[] | undefined> = {};

  for (const [key, value] of Object.entries(headers)) {
    if (sensitiveHeaders.has(key.toLowerCase())) {
      continue;
    }

    cleanedHeaders[key] = value;
  }

  return cleanedHeaders;
}

function logBiometricRequest(req: IClockRequest) {
  console.log(`[BIOMETRIC REQUEST] [${new Date().toISOString()}]`);
  console.log(`- Method: ${req.method}`);
  console.log(`- Full URL: ${getRequestUrl(req)}`);
  console.log(`- Query: ${JSON.stringify(req.query)}`);
  console.log(`- Headers: ${JSON.stringify(sanitizeHeaders(req.headers))}`);
  console.log(`- SN: ${getDeviceSerialNumber(req) || "UNKNOWN_SN"}`);
  console.log(`- Table: ${getTableName(req) || "(not provided)"}`);
  console.log(`- Timestamp: ${new Date().toISOString()}`);
  console.log(`- Raw Body:\n${req.rawBody || "(empty)"}`);
  console.log("----------------------------------------");
}

function getRawBodyContent(req: IClockRequest): string {
  if (typeof req.rawBody === "string" && req.rawBody.length > 0) {
    return req.rawBody;
  }
  if (Buffer.isBuffer(req.body)) {
    return req.body.toString("utf8");
  }
  if (typeof req.body === "string") {
    return req.body;
  }
  if (req.body && typeof req.body === "object") {
    try {
      return JSON.stringify(req.body);
    } catch {
      return "";
    }
  }
  return "";
}

function shouldAutoQueryAttendance(serialNumber: string) {
  if (!serialNumber) return false;
  const lastQueuedAt = lastAttendanceAutoQueryBySn.get(serialNumber) || 0;
  return Date.now() - lastQueuedAt >= attendanceAutoQueryCooldownMs;
}

async function persistBiometricLog(req: IClockRequest, status: string, errorMessage?: string) {
  try {
    await prisma.biometricRawLog.create({
      data: {
        deviceSerialNumber: getDeviceSerialNumber(req) || "UNKNOWN_SN",
        requestMethod: req.method || "UNKNOWN",
        requestPath: req.originalUrl || req.path || "/iclock",
        queryParameters: JSON.stringify(req.query || {}),
        headers: JSON.stringify(sanitizeHeaders(req.headers || {})),
        rawPayload: getRawBodyContent(req),
        processingStatus: status,
        errorMessage: errorMessage || null
      }
    });
  } catch (databaseError) {
    console.error("[Biometric] Failed to persist raw log:", databaseError);
  }
}
